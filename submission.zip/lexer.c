/* $Id: lexer.c,v 1.5 2024/10/06 01:25:18 leavens Exp $ */

#include "lexer.h"

// All the functions declared in lexer.h are
// defined in the user code section of spl_lexer.l
